import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

public class MazeSolver {
    // assummign the maze grid wont be  more than 10000*10000
    private  static  final boolean [][] visited = new boolean[10000][10000];

    public static void main(String[] args) {

    }
}
