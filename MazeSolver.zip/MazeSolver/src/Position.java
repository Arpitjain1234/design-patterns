public class Position {

    int row;
    int col;

    Position (int r,int c){
        this.row =r;
        this.col = c;

    }

}
