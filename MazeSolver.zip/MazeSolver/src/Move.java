public class Move {
    Position from;
    Position to;

    Move(Position from, Position to){
        this.from = from;
        this.to = to;
    }
}
